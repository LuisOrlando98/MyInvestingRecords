export const sendEmail = async (to, subject, html) => {
  console.log("Simulated email:");
  console.log("To:", to);
  console.log("Subject:", subject);
  console.log("HTML:", html);
};
